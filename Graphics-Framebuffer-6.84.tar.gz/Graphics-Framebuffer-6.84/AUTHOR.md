# Richard Kelsch

I am a Perl Programmer and Linux System Administrator by profession.  I specialize in code optimization and multi-threading.  I have been coding professionally for nearly 4 decades.  I am a published author as well.

* **GitHub** - https://github.com/richcsst
