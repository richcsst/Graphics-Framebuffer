# IMPORTANT

The images in this directory were available on the public Internet, and are
property of their various authors.  They are here for demonstration purposes
only, and constitutes "fair use".  I do not claim any rights to them
whatsoever.

This also means you do NOT have any rights to use them in any commercial
project without their written permission and/or license.
